#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Subsystems/ProjectilesSubsystem.h"
#include "Combat/AttackPatterns.h"
#include "BulletSpawnerComponent.generated.h"

class IAttackStrategy;

enum class EAttackType : uint8
{
	Circle,
	Sphere,
	Spiral,
	Burst,
	// otros tipos de ataque
};

struct FAttackStep
{	
	EAttackType Type;
	int32 BulletCount;
	float Speed;
	float DelayAfter;
	float SpecialParam;
	bool bUseBossLocation; // Si genera en el boss o en otro lugar
	FVector CustomOrigin; // Si bUseBossLocation es false
	float Damage;

	/**
	* Constructor por defecto, genera un ataque circular con 10 balas, velocidad 500, delay de 1 segundo, sin par�metros especiales y origen en el boss. Esto es solo para facilitar la creaci�n de ataques simples, se pueden usar los otros constructores para m�s control.
	* Los par�metros, en orden, son Tipo de ataque, Cantidad de balas, Velocidad, Delay despu�s del ataque, Par�metro especial (dependiendo del tipo de ataque), Si usa la ubicaci�n del boss o no, y la ubicaci�n personalizada si no se usa la del boss.
	*/
	FAttackStep() : Type(EAttackType::Circle), BulletCount(10), Speed(500.0f), DelayAfter(1.0f), SpecialParam(0.0f), bUseBossLocation(true), CustomOrigin(FVector::ZeroVector), Damage(10.0f) {}

	// * Constructor para ataques desde boss. En cuyo caso el Origen es ZeroVector
	FAttackStep(EAttackType InType, int32 InCount, float InSpeed, float InDelay, float InSpecial = 0.0f, float InDamage = 10.0f) 
		: Type(InType), BulletCount(InCount), Speed(InSpeed), DelayAfter(InDelay), SpecialParam(InSpecial), bUseBossLocation(true), CustomOrigin(FVector::ZeroVector), Damage(InDamage) {}

	// * Constructor para ataques en ubicaci�n espec�fica, donde el origen es diferente del boss
	FAttackStep(EAttackType InType, int32 InCount, float InSpeed, float InDelay, FVector InOrigin, float InSpecial = 0.0f, float InDamage = 10.0f)
		: Type(InType), BulletCount(InCount), Speed(InSpeed), DelayAfter(InDelay), SpecialParam(InSpecial), bUseBossLocation(false), CustomOrigin(InOrigin), Damage(InDamage) {}
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class BULLETRUSH_API UBulletSpawnerComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UBulletSpawnerComponent();
	/**
	* Empieza una secuencia de ataques, cada uno definido por un FAttackStep. El componente se encargar� de ejecutar cada paso en orden, respetando los tiempos de delay y utilizando las estrategias de ataque correspondientes al tipo de ataque definido en cada paso.
	*/
	void StartSequence(const TArray<FAttackStep>& NewSequence);
	/**
	* Genera las balas en el mundo. Esta funci�n es llamada por las estrategias de ataque para crear las balas con la direcci�n y velocidad adecuadas. El origen puede ser el jefe o una ubicaci�n espec�fica, dependiendo de los par�metros del ataque.
	*/
	void InternalSpawn(FVector Origin, FVector Direction, float Speed, float Damage);

	void StopCurrentSequence();

protected:
	virtual void BeginPlay() override;
	
public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override; // Ni idea si usemos esto despu�s, lo dejo por si acaso
	

private:
	//float CurrentSpiralAngle = 0.0f;
	//FTimerHandle BurstTimerHandle;
	//int32 BulletsLeftToBurst;
	//float CachedBurstSpeed;

	//void ExecuteBurstStep();

	TArray<FAttackStep> CurrentSequence;
	int32 CurrentStepIndex;
	FTimerHandle SequenceTimerHandle;
	/**
	* Ejecuta el siguiente paso en la secuencia de ataques. Esta funci�n es llamada autom�ticamente despu�s de cada ataque, utilizando el tiempo de delay definido en el paso actual para programar la ejecuci�n del siguiente paso.
	*/
	void ExecuteNextStep();
	TMap<EAttackType, TSharedPtr<IAttackStrategy>> AttackRegist;

	UProjectilesSubsystem* ProjectilesSubsystem;

	bool bIsPlayerSource = false;
};
