// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Enemies/EnemyBase.h"
#include "Components/HealthComponent.h"
#include "Components/WeakPointComponent.h"
#include "Components/StaticMeshComponent.h"
#include "BossBase.generated.h"

class UShapeComponent;
class UBulletSpawnerComponent;
class UWeakPointComponent;

UENUM(BlueprintType)
enum class EBossState : uint8
{
	// Jefe invulnerable, ejecuta "animaci�n" de entrada
	Intro UMETA(DisplayName = "Introduccion"),
	Attacking UMETA(DisplayName = "Ejecutando Patr�n"),
	Idle UMETA(DisplayName = "Moviendose / Esperando"),
	Stunned UMETA(DisplayName = "Indefenso"),
	PhaseTransition UMETA(DisplayName = "Cambio de Fase"),
	Dead UMETA(DisplayName = "Derrotado/Muerto")
};

UCLASS()
class BULLETRUSH_API ABossBase : public AEnemyBase
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	ABossBase();

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Boss Logic")
	EBossState CurrentState;

	// ya existe en el componente health UPROPERTY(VisibleAnywhere, Category = "Boss Logic")
	// ya existe en el componente health bool bIsInvulnerable;

	int32 AttackIdentifier = 0; // Define que patr�n de ataque utilizar

	// Cu�ntos puntos d�biles le quedan vivos
    int32 ActiveWeakPoints;

    // Funci�n que se ejecutar� cuando un punto d�bil grite
    UFUNCTION()
    virtual void HandleWeakPointDestroyed();

	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	virtual void SetBossState(EBossState NewState);

	virtual void Attack();

	// Mesh para la nave, cada hijo puede usarla
	UPROPERTY(VisibleAnywhere, Category = "Components")
	UStaticMeshComponent* BossMesh;

	// La HitBox se usar� en caso de que la mesh no tenga colisiones bien definidas
	//UPROPERTY(VisibleAnywhere, Category = "Components")
	//UShapeComponent* Hitbox; // Hitbox est�tica, no se como aplicar la hitbox para un gusano de multiples partes :)

	// ya existe en el componente health float MaxHealth = 4000.0f;
	// ya existe en el componente health float CurrentHealthh = 4000.0f;
	
	FTimerHandle IntroTimer;
	FTimerHandle StunnedTimer;
	FTimerHandle PhaseTransitionTimer;

	void SetInvulnerable(bool newstate);

	UBulletSpawnerComponent* BulletSpawner;
	FTimerHandle AttackLoopTimer;

	UWeakPointComponent* TestWeak;

	TArray<FAttackStep> Combo;
	TArray<FAttackStep> Combo2;

	void Die() override;
};
