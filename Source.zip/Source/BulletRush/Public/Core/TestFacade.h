// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TestFacade.generated.h"

class APlayingPlayer;

UCLASS()
class BULLETRUSH_API ATestFacade : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ATestFacade();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	void SummonBoss(FVector Location);
	void SummonEnemies(FVector Center,int NoEnemies);

	UWorld* World;

};
