// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BulletRushGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class BULLETRUSH_API ABulletRushGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
public:
	ABulletRushGameModeBase();
	virtual void BeginPlay() override;

	UFUNCTION(Exec)
	void DealDamageToTarget(float Damage);

	/*
	// Esta funci�n permite decidir qu� Pawn usar din�micamente
	virtual UClass* GetDefaultPawnClassForController_Implementation(AController* InController) override;
	*/
};
