// Fill out your copyright notice in the Description page of Project Settings.


#include "Map/LevelPortal.h"
#include "Components/StaticMeshComponent.h"
#include "Components/BoxComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Player/TopDownPlayer.h"
#include "Subsystems/LevelRoutingSubsystem.h"

#include "Core/Publisher.h"

//mas testeo
#include "Player/PlayingPlayer.h"

// Sets default values
ALevelPortal::ALevelPortal()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	
	
	CollisionBox = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerBox"));
	CollisionBox->SetBoxExtent(FVector(10.0f, 10.0f, 10.0f));
	RootComponent = CollisionBox;


	//malla  para la caja
	PortalMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PortalMesh"));
	PortalMesh->SetupAttachment(RootComponent);
	// descativamos las colisiones de la malla
	PortalMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	
	static ConstructorHelpers::FObjectFinder<UStaticMesh> MeshAsset(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_NarrowCapsule.Shape_NarrowCapsule'"));

	if (MeshAsset.Succeeded())
	{
		PortalMesh->SetStaticMesh(MeshAsset.Object);
		//ubicacion respecto al box
		PortalMesh->SetRelativeLocation(FVector(0.0f, 0.0f, 10.0f));
	}

	CollisionBox->OnComponentBeginOverlap.AddDynamic(this, &ALevelPortal::OnOverlapBegin);


}

// Called when the game starts or when spawned
void ALevelPortal::BeginPlay()
{
	Super::BeginPlay();

}
void ALevelPortal::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	// Verificamos que el actor que choc� no sea nulo y no sea el portal mismo
	if (OtherActor && OtherActor != this)
	{
		// verificamos que el actor que choco sea el jugador 
		//referencia al player TopDown
		ATopDownPlayer* Player = Cast<ATopDownPlayer>(OtherActor);
		//testeo referencai al playingplayer
		APlayingPlayer* Player2 = Cast<APlayingPlayer>(OtherActor);
		if ((Player || Player2) && !TargetLevelName.IsNone())
		{
			ULevelRoutingSubsystem* LevelRouter = GetGameInstance()->GetSubsystem<ULevelRoutingSubsystem>();
			if (LevelRouter)
			{
				LevelRouter->SolicitarViajeANivel(TargetLevelName, this);
			}
			/*
			//cargamos el nivel corespondiente
			UGameplayStatics::OpenLevel(this, TargetLevelName);
			UE_LOG(LogTemp, Warning, TEXT("Playerrr a entrado al nivel %s"), *TargetLevelName.ToString());
			*/
		}
	}
}

// Called every frame
void ALevelPortal::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ALevelPortal::Update(APublisher* Publisher)
{
	// Simple update reaction: activate portal or change visual. For now no-op.
	UE_LOG(LogTemp, Log, TEXT("ALevelPortal::Update called by Publisher %s"), Publisher ? *Publisher->GetName() : TEXT("(null)"));
}

